﻿using HospitalApp.Models;
using HospitalAppLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HospitalApp.Views.Pages
{
    /// <summary>
    /// Логика взаимодействия для BreakRecordPage.xaml
    /// </summary>
    public partial class BreakRecordPage : Page
    {
        TimeFieldsClass timeFieldsObj = new TimeFieldsClass();
        Core db = new Core();
        public BreakRecordPage()
        {
            InitializeComponent();
            List<TypesEvent> typesEvents = db.context.TypesEvent.ToList();
            List<string> typesTitlelist = new List<string>();
            foreach (TypesEvent typeEvent in typesEvents)
            {
                typesTitlelist.Add(typeEvent.TypeTitle);
            }
            EventTypeComboBox.ItemsSource = typesTitlelist;
            EventTypeComboBox.SelectedIndex = 0;
        }


        private void CreateSheduleButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(timeFieldsObj.IsRightTime(EventStartTimeTextBox.Text).ToString());
        }
    }
}
