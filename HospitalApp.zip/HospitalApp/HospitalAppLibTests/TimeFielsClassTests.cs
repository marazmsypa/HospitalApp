﻿using HospitalAppLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace HospitalAppLibTests
{
    [TestClass]
    public class TimeFielsClassTests
    {
        TimeFieldsClass timeFieldsObj = new TimeFieldsClass();
        [TestMethod]
        public void IsRightTime_EmptyString_ReturnFalse()
        {
            //Arrange
            string entryString = "";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightTime(entryString));
        }

       
        [TestMethod]
        public void IsRightTime_Word_ReturnFalse()
        {
            //Arrange
            string entryString = "приветт";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightTime(entryString));
        }

        [TestMethod]
        public void IsRightTime_WrongTimeHoursRecord_ReturnFalse()
        {
            //Arrange
            string entryString = "25:00";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightTime(entryString));
        }

        [TestMethod]
        public void IsRightTime_WrongTimeMinutesRecord_ReturnFalse()
        {
            //Arrange
            string entryString = "23:60";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightTime(entryString));
        }


        [TestMethod]
        public void IsRightTime_RightTimeMinutesRecord_ReturnTrue()
        {
            //Arrange
            string entryString = "23:08";


            //Assert
            Assert.IsTrue(timeFieldsObj.IsRightTime(entryString));
        }

        [TestMethod]
        public void IsRightTime_RightTimeHoursRecord_ReturnTrue()
        {
            //Arrange
            string entryString = "08:08";


            //Assert
            Assert.IsTrue(timeFieldsObj.IsRightTime(entryString));
        }

        [TestMethod]
        public void IsRightDuration_NullEntry_ReturnFalse()
        {
            //Arrange
            string entryString = "";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightDuration(entryString));
        }

        [TestMethod]
        public void IsRightDuration_WrongEntry_ReturnFalse()
        {
            //Arrange
            string entryString = "privet";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightDuration(entryString));
        }

        [TestMethod]
        public void IsRightDuration_WrongNumber_ReturnFalse()
        {
            //Arrange
            string entryString = "80";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightDuration(entryString));
        }

        [TestMethod]
        public void IsRightDuration_WrongNumberWithFirstSix_ReturnFalse()
        {
            //Arrange
            string entryString = "67";


            //Assert
            Assert.IsFalse(timeFieldsObj.IsRightDuration(entryString));
        }

        [TestMethod]
        public void IsRightDuration_RightOneNumber_ReturnTrue()
        {
            //Arrange
            string entryString = "0";


            //Assert
            Assert.IsTrue(timeFieldsObj.IsRightDuration(entryString));
        }
        
        [TestMethod]
        public void IsRightDuration_RightTwoNumbers_ReturnTrue()
        {
            //Arrange
            string entryString = "60";


            //Assert
            Assert.IsTrue(timeFieldsObj.IsRightDuration(entryString));
        }
    }
}
